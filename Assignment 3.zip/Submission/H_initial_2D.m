% Defines initial depth in 2D
function depth = H_initial_2D(x,y) 
depth = 2.0; % initial depth of the water
dam_wall = 0.50; % dam wall to keep the water trap within the damwall (a box)

if x > dam_wall || x < - dam_wall || y > dam_wall || y < - dam_wall
    depth = 1.0;
end

end