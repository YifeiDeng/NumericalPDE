%Function for lamda_max i bar and lamda_max i+1 bar in 2D
function [Lamda_max_bar1_x, Lamda_max_bar2_x, Lamda_max_bar1_y, Lamda_max_bar2_y] = lamda_max_2D(hu_i,h_i,hu_i_p_1_x,h_i_p_1_x,hu_i_m_1_x,h_i_m_1_x,hu_i_y,hu_i_p_1_y,h_i_p_1_y,hu_i_m_1_y,h_m_1_y,g)
Lamda_max_bar1_x = max(abs(hu_i ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1_x ./ h_i_p_1_x + sqrt(g * h_i_p_1_x))); %for i+1/2,j in x direction
Lamda_max_bar2_x = max(abs(hu_i_m_1_x ./ h_i_m_1_x + sqrt(g * h_i_m_1_x)), abs(hu_i ./ h_i + sqrt(g * h_i))); %for i-1/2,j in x direction
Lamda_max_bar1_y = max(abs(hu_i_y ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1_y ./ h_i_p_1_y + sqrt(g * h_i_p_1_y))); %for i,j+1/2 in y direction
Lamda_max_bar2_y = max(abs(hu_i_m_1_y ./ h_m_1_y + sqrt(g * h_m_1_y)), abs(hu_i_y ./ h_i + sqrt(g * h_i))); %for i,j-1/2 in y direction
end