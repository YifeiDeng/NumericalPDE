function Dam_Break_2D
%% ===================clear environment====================================

clear
close all
clc   
clf

%% =====================initialized some conditions========================

m = 60; %Number of grids for both x and y domain
p = -1.0; %the left end of both x & y domain
q = 1.0; %the right end of both x & y domain
dx = (q-p)/m; %grid spacing in x direction
dy = (q-p)/m; %grid spacing in y direction
t_1 = 1.35; %time for plot 1
t_end = 3.0; %time for plot 2
t = 0; % intitialized the time for increment
c = 0.8; %the safty constant
g = 1.0; % the gravitational acceleration
iteration = 0; %use to count the total time steps run

[x,y] = meshgrid(((p + dx/2):dx:(q - dy/2)),((p + dy/2):dy:(q - dy/2))); %set up the mesh for x&y (m^2 = 3600), in this case + or - dx dy because regard it as a cell centered FVM

h = zeros(size(x)); % initialized the depth
u = zeros(size(x)); % Sets initial velocity for horizontal velocity
v = zeros(size(x)); % Sets initial velocity for vertical velocity

U1 = zeros(size(x));% Ui is conserved quantities matrix for v i+1. i.e. U1=h, U2=hu, U3=hv
U2 = zeros(size(x));
U3 = zeros(size(x));

for i = 1 : m
    for j = 1 : m
        h(i,j) = H_initial_2D(x(i,j),y(i,j)); % Sets initial stream depth
    end
end

[h, u, v] = boundary_2D(h,u,v,m);  % Sets ghost cell for depth and velocities in 2D
[un1, un2, un3, F1, F2, F3, G1, G2, G3] = initial_2D(h,u,v,g); % Sets initial conserved quantities and flux variables in 2D

%start with the initial condition
mesh(x,y,h(2:m+1,2:m+1))
colormap winter
axis([-1 1 -1 1 0.5 2.5])
title('Press enter to continue')
xlabel x
ylabel y
zlabel h
pause
styles = {'k:','k--','k-'}

% %start with define figure for gif
% fig = figure;

%% ===================== Runs similation ==================================
while t < t_end
    dt = time_step_2D(dx,dy,c,u,v,g,h); % Calculates dt
    t = t + dt; % Calulate the culmulative time steps for stopping criterion
    delta_X = dt/dx; % Define variable for dt/dx for computaiton convenience
    delta_Y = dt/dy; % Define variable for dt/dy for computaiton convenience
    iteration = iteration + 1; % count the number of time steps for creating gif
    Vol = 0; %initialized the amount of water
        
    for i = 2:m+1
        for j = 2:m+1
            [Lamda_max_bar1_x, Lamda_max_bar2_x, Lamda_max_bar1_y, Lamda_max_bar2_y] = lamda_max_2D(un2(i,j),un1(i,j),un2(i+1,j),un1(i+1,j),un2(i-1,j),un1(i-1,j),un3(i,j),un3(i,j+1),un1(i,j+1),un3(i,j-1),un1(i,j-1),g);
            U1(i,j) = un1(i,j) - 0.5 * delta_X * (F1(i+1,j) - F1(i-1,j) - Lamda_max_bar1_x * (un1(i+1,j) - un1(i,j)) ...
                                                  + Lamda_max_bar2_x * (un1(i,j) - un1(i-1,j)))...
                               - 0.5 * delta_Y * (G1(i,j+1) - G1(i,j-1) - Lamda_max_bar1_y * (un1(i,j+1) - un1(i,j)) ...
                                                  + Lamda_max_bar2_y * (un1(i,j) - un1(i,j-1)));  
            U2(i,j) = un2(i,j) - 0.5 * delta_X * (F2(i+1,j) - F2(i-1,j) - Lamda_max_bar1_x * (un2(i+1,j) - un2(i,j)) ...
                                                  + Lamda_max_bar2_x * (un2(i,j) - un2(i-1,j)))...
                               - 0.5 * delta_Y * (G2(i,j+1) - G2(i,j-1) - Lamda_max_bar1_y * (un2(i,j+1) - un2(i,j)) ...
                                                  + Lamda_max_bar2_y * (un2(i,j) - un2(i,j-1)));   
            U3(i,j) = un3(i,j) - 0.5 * delta_X * (F3(i+1,j) - F3(i-1,j) - Lamda_max_bar1_x * (un3(i+1,j) - un3(i,j)) ...
                                                  + Lamda_max_bar2_x * (un3(i,j) - un3(i-1,j)))...
                               - 0.5 * delta_Y * (G3(i,j+1) - G3(i,j-1) - Lamda_max_bar1_y * (un3(i,j+1) - un3(i,j)) ...
                                                  + Lamda_max_bar2_y * (un3(i,j) - un3(i,j-1)));   
        end
    end
    
    [h,u,v] = Re_initial_2D(U1,U2,U3,m); % reset conserved variables for next round
    
    %Calculated the volume (at each time propagation)
    for i = 2:m+1
        for j = 2:m+1
            Vol = Vol + h(i,j) * dx * dy;
        end
    end
    
    %% Plotting
    % Movie
    figure(2)
    mesh(x,y,h(2:m+1,2:m+1)), % display a movie of depth
    colormap winter
    axis ([-1 1 -1 1 0 3.0])
    title({['Movie of Height at t = ' num2str(t)];['Vol = ', num2str(Vol)]})
    xlabel x[m]
    ylabel y[m] 
    zlabel h[m] 
    pause(0.01)
    
%     %Code for storing the gif
%     frame = getframe(fig);
%     im{iteration} = frame2im(frame);
    
    
    %For specific time
    if (t_1 == round(t,2))
        figure(3)
        mesh(x,y,h(2:m+1,2:m+1)), % display a movie of height
        colormap winter, 
        axis ([-1 1 -1 1 0 3.0])
        title(['3D Plot for Dam Break in 2-D at t = ' num2str(t)])
        xlabel x[m]
        ylabel y[m]
        zlabel h[m]
    elseif (t_end == round(t,2))
        figure(4)
        mesh(x,y,h(2:m+1,2:m+1)), % display a movie of height
        colormap winter, 
        axis ([-1 1 -1 1 0 3.0])
        title(['3D Plot for Dam Break in 2-D at t = ' num2str(t)])
        xlabel x[m]
        ylabel y[m]
        zlabel h[m]
    end
    
    % plot of h integrated over spatial domain
    figure(5)
    hold on
    plot(t,Vol,'*r-')
    axis ([0 3.0 4.995 5.005])
    xlabel t
    ylabel V[m\^3]
    title('Plot of h integrate over the spatial domain as a function of time')
    hold off
    
    %% store this round vn+1 for the next time step
    [un1, un2, un3, F1, F2, F3, G1, G2, G3] = initial_2D(h,u,v,g); % using the reset conserved variables calculate vn for next time step
end
% %close for storing the image for gif
% close;
% 
% %generated gif in local directory
% filename = 'Dam_breaking_2D_Animated.gif'; % Specify the output file name
% for idx = 1:iteration
%     [A,map] = rgb2ind(im{idx},256);
%     if idx == 1
%         imwrite(A,map,filename,'gif','LoopCount',Inf,'DelayTime',0.001);
%     else
%         imwrite(A,map,filename,'gif','WriteMode','append','DelayTime',0.001);
%     end
% end



end


%% ======================= End of the Main Function =======================


%% ======================= Start of Supporting functions ==================
function depth = H_initial_2D(x,y) % Defines initial depth in 2D
depth = 2.0; % initial depth of the water
dam_wall = 0.50; % dam wall to keep the water trap within the damwall (a box)

if x > dam_wall || x < - dam_wall || y > dam_wall || y < - dam_wall
    depth = 1.0;
end

end

function [h,u,v] = boundary_2D(h1,u1,v1,m) % Function to impose ghost cells at the spatial boundaries in 2D
h = [h1(:,1) h1 h1(:,m)]; %impose boundary condition on h
h = [h(1,:); h ;h(m,:)];
u = [u1(:,1) u1 u1(:,m)]; %impose boundary condition on u, change sign for normal component (x direct)
u = [-u(1,:); u ;-u(m,:)];
v = [-v1(:,1) v1 -v1(:,m)]; %impose boundary condition on v, change sign for normal component (y direct)
v = [v(1,:); v ;v(m,:)];
end

function [un1, un2, un3, F1, F2, F3, G1, G2, G3] = initial_2D(h,u,v,g) % Defines initial conserved variables and flux function
un1 = h; % set conserved variables
un2 = h.*u;
un3 = h.*v;

F1 = h.*u; % set flux variables correspondingly for flux F in x-direction
F2 = h.*u.^2 + (g.*h.^2) / 2;
F3 = h.*u.*v;

G1 = h.*v; % set flux variables correspondingly for flux G in y-direction
G2 = h.*u.*v;
G3 = h.*v.^2 + (g.*h.^2) / 2;
end

function dt  = time_step_2D(dx,dy,c,u,v,g,h) % Function to calculate time steps in 2D
Lamda_max_x = max(abs(u) + sqrt(g * h)); % Calculates max wave speed for x
Lamda_max_y = max(abs(v) + sqrt(g * h)); % Calculates max wave speed for y
dt = 0.5 * c * min(min(dx ./ Lamda_max_x), min(dy ./ Lamda_max_y)); % Calculates timestep
end

function [Lamda_max_bar1_x, Lamda_max_bar2_x, Lamda_max_bar1_y, Lamda_max_bar2_y] = lamda_max_2D(hu_i,h_i,hu_i_p_1_x,h_i_p_1_x,hu_i_m_1_x,h_i_m_1_x,hu_i_y,hu_i_p_1_y,h_i_p_1_y,hu_i_m_1_y,h_m_1_y,g) %Function for lamda_max i bar and lamda_max i+1 bar in 2D
Lamda_max_bar1_x = max(abs(hu_i ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1_x ./ h_i_p_1_x + sqrt(g * h_i_p_1_x))); %for i+1/2,j in x direction
Lamda_max_bar2_x = max(abs(hu_i_m_1_x ./ h_i_m_1_x + sqrt(g * h_i_m_1_x)), abs(hu_i ./ h_i + sqrt(g * h_i))); %for i-1/2,j in x direction
Lamda_max_bar1_y = max(abs(hu_i_y ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1_y ./ h_i_p_1_y + sqrt(g * h_i_p_1_y))); %for i,j+1/2 in y direction
Lamda_max_bar2_y = max(abs(hu_i_m_1_y ./ h_m_1_y + sqrt(g * h_m_1_y)), abs(hu_i_y ./ h_i + sqrt(g * h_i))); %for i,j-1/2 in y direction
end

function[h,u,v] = Re_initial_2D(U1,U2,U3,m) % Function that re-Define conserved variables and flux function for each iteration in 2D
h = U1(2:m+1,2:m+1); % Calculates new h, u, v values for Lax-F
u = U2(2:m+1,2:m+1)./U1(2:m+1,2:m+1); % Reset without the ghost cell imposed
v = U3(2:m+1,2:m+1)./U1(2:m+1,2:m+1); % Reset without the ghost cell imposed

[h,u,v] = boundary_2D(h,u,v,m);  % Consider ghost cells again
end
% ======================= The End of Program ==============================
