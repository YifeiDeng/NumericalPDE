%Q2 part b)
clear;
%try rho_2_1 = linspace(0,100,100000000);
%    s = linspace(0,100,100000000);
% we have solution for r = rho = 1 and k = s = 1
%first, our analytical solution

%try rho_2_1 = linspace(0,100,20000000);
%s = linspace(0,100,20000000);
%we have solution for r = rho = 1.6050 and k = s = 1.6050
%second

%try rho_2_1 = linspace(0,100,100000000);
%s = linspace(0,10,100000000);
%we have solution for r = rho = 4.418 and k = s = 0.4418
%third and forth


rho_2_1 = linspace(0,100,100000000);
s = linspace(0,10,100000000);

fcn = @(rho_2,s)4 + s - 4 ./rho_2 - s.* rho_2.^(7/5);

for i = 1:length(rho_2_1)
    if round(fcn(rho_2_1(i),s(i)),6) == 0
            r = rho_2_1(i)
            k = s(i)
            disp(i)
    end
end

%check with the solutions for rho and s:entropy
%could see all with small error and we check our anlytical solution rho = 1
%case with s = 0.1
fcn(1,1)
fcn(1.6050, 1.6050)
fcn(4.418,0.4418)

%also we have rho_2 = 1, s = 0.1 a solution
fcn(1, 0.1)
