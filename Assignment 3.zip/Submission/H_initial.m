% Defines initial depth
function depth = H_initial(x)
depth = 2.0; % initial depth of the water on the upstream of the dam
dam_wall = 0; % dam wall to seperate the up & down side of the stream

if x >= dam_wall 
    depth = 1.0; % define depth of the downstream after the damwall  
end

end

