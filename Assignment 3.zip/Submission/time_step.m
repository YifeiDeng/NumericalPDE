% Function to calculate time steps
function dt  = time_step(dx,c,u,g,h) % Function to calculate time steps 
Lamda_max = max(abs(u) + sqrt(g * h)); % Calculates max wave speed
dt = c * min(dx / Lamda_max); % Calculates timestep
end


