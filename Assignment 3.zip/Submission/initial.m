% Defines initial conserved variables and flux function
function [un1, un2, un3, F1, F2, F3] = initial(h,u,v,g)
un1 = h; % set conserved variables
un2 = h.*u;
un3 = h.*v;

F1 = h.*u; % set flux variables correspondingly
F2 = h.*u.^2 + (g.*h.^2) / 2;
F3 = h.*u.*v;
end

