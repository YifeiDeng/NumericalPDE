%Function for lamda_max i bar and lamda_max i+1 bar
function [Lamda_max_bar1, Lamda_max_bar2] = lamda_max(hu_i,h_i,hu_i_p_1,h_i_p_1,hu_i_m_1,h_i_m_1,g)
Lamda_max_bar1 = max(abs(hu_i ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1 ./ h_i_p_1 + sqrt(g * h_i_p_1))); %for i+1/2
Lamda_max_bar2 = max(abs(hu_i_m_1 ./ h_i_m_1 + sqrt(g * h_i_m_1)), abs(hu_i ./ h_i + sqrt(g * h_i)));% for i-1/2
end