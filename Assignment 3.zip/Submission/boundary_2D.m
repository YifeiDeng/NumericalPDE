% Function to impose ghost cells at the spatial boundaries in 2D
function [h,u,v] = boundary_2D(h1,u1,v1,m) 
h = [h1(:,1) h1 h1(:,m)]; %impose boundary condition on h
h = [h(1,:); h ;h(m,:)];
u = [u1(:,1) u1 u1(:,m)]; %impose boundary condition on u, change sign for normal component (x direct)
u = [-u(1,:); u ;-u(m,:)];
v = [-v1(:,1) v1 -v1(:,m)]; %impose boundary condition on v, change sign for normal component (y direct)
v = [v(1,:); v ;v(m,:)];
end