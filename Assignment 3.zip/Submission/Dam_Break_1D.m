function Dam_Break_1D
%% ===================clear environment====================================

clear
close all
clc   
clf

%% =====================initialized some conditions========================

m = 100; %Number of grids
p = -1.0; %the left end of x domain
q = 1.0; %the right end of x domain
dx = (q-p)/m; %grid spacing
t_1 = 0.25; %time for plot 1
t_end = 0.5; %time for plot 2
t = 0; % intitialized the time for increment
c = 0.5; %the safty constant
g = 1.0; % the gravitational acceleration
h = zeros(1,m); % initialized the depth
U1 = zeros(1,m+2); % define vi+1 for h
U2 = zeros(1,m+2); % define vi+1 for hu
U3 = zeros(1,m+2); % define vi+1 for hv


x = ((p+dx/2):dx:(q-dx/2)); %spatial grid, because regard it as a cell centered FVM

for i = 1 : m
    h(i) = H_initial(x(i)); % Sets initial stream depth
end

u = zeros(1,m); % Sets initial velocity for horizontal velocity
v = zeros(1,m); % Sets initial velocity for vertical velocity

[h, u, v] = boundary(h,u,v,m);  % Sets ghost cell for depth and velocity
[un1, un2, un3, F1, F2, F3] = initial(h,u,v,g); % Sets initial conserved variables and flux variables

%% ===================== Runs similation ==================================
while t < t_end
    dt = time_step(dx,c,u,g,h); % Calculates dt
    t = t + dt % Calulate the culmulative time steps for stopping criterion
    delta = dt/dx; % Define variable for dt/dx for computaiton convenience
        
    for i = 2:m+1
        [Lamda_max_bar1, Lamda_max_bar2] = lamda_max(un2(i),un1(i),un2(i+1),un1(i+1),un2(i-1),un1(i-1),g);
        U1(i) = un1(i) - 0.5 * delta * (F1(i+1) - F1(i-1) - Lamda_max_bar1 * (un1(i+1) - un1(i)) ...
                                        + Lamda_max_bar2 * (un1(i) - un1(i-1)));  
        U2(i) = un2(i) - 0.5 * delta * (F2(i+1) - F2(i-1) - Lamda_max_bar1 * (un2(i+1) - un2(i)) ...
                                        + Lamda_max_bar2 * (un2(i) - un2(i-1)));  
        U3(i) = un3(i) - 0.5 * delta * (F3(i+1) - F3(i-1) - Lamda_max_bar1 * (un3(i+1) - un3(i)) ...
                                        + Lamda_max_bar2 * (un3(i) - un3(i-1)));  
    end
    
    [h,u,v] = Re_initial(U1,U2,U3,m); % reset conserved variables for next round
    
    %% Plotting
    
    %Movie of plot for h, u & v
    figure(1)
    subplot(3,1,1)
    plot(x, h(2:m+1),'-ob') % Plots water depth for each timestep.
    axis([p q min(h) 1.1*max(h)])
    xlabel('x [m]','Fontsize', 12)
    ylabel('h [m]', 'Fontsize', 12)
    title(['Water Depth for Lax-Friedrichs Scheme at t = ' num2str(t)])
    
    subplot(3,1,2)
    plot(x, u(2:m+1),'-ok') % Plots water velocity for each timestep.
    axis([p q min(u) max(u)])
    xlabel('x [m]','Fontsize', 12)
    ylabel('u [m/s]', 'Fontsize', 12)
    title(['Water Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])
    
    subplot(3,1,3)
    plot(x, v(2:m+1),'-ok') % Plots vertical velocity for each timestep.
    axis auto
    xlabel('x [m]','Fontsize', 12)
    ylabel('v [m/s]', 'Fontsize', 12)
    title(['Vertical Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])
    pause(0.1)
    
    %For specific time t = 0.25 and t = 0.5
    if (t_1 == round(t,2))
        figure(2)
        subplot(3,1,1)
        plot(x, h(2:m+1),'-ob') % Plots water depth for each timestep.
        axis([p q min(h) 1.1*max(h)])
        xlabel('x [m]','Fontsize', 12)
        ylabel('h [m]', 'Fontsize', 12)
        title(['Water Depth for Lax-Friedrichs Scheme at t = ' num2str(t)])

        subplot(3,1,2)
        plot(x, u(2:m+1),'-ok') % Plots water velocity for each timestep.
        axis([p q min(u) max(u)])
        xlabel('x [m]','Fontsize', 12)
        ylabel('u [m/s]', 'Fontsize', 12)
        title(['Water Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])

        subplot(3,1,3)
        plot(x, v(2:m+1),'-ok') % Plots vertical velocity for each timestep.
        axis auto
        xlabel('x [m]','Fontsize', 12)
        ylabel('v [m/s]', 'Fontsize', 12)
        title(['Vertical Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])
    elseif (t_end == round(t,2))
        figure(3)
        subplot(3,1,1)
        plot(x, h(2:m+1),'-ob') % Plots water depth for each timestep.
        axis([p q min(h) 1.1*max(h)])
        xlabel('x [m]','Fontsize', 12)
        ylabel('h [m]', 'Fontsize', 12)
        title(['Water Depth for Lax-Friedrichs Scheme at t = ' num2str(t)])

        subplot(3,1,2)
        plot(x, u(2:m+1),'-ok') % Plots water velocity for each timestep.
        axis([p q min(u) max(u)])
        xlabel('x [m]','Fontsize', 12)
        ylabel('u [m/s]', 'Fontsize', 12)
        title(['Water Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])

        subplot(3,1,3)
        plot(x, v(2:m+1),'-ok') % Plots vertical velocity for each timestep.
        axis auto
        xlabel('x [m]','Fontsize', 12)
        ylabel('v [m/s]', 'Fontsize', 12)
        title(['Vertical Velocity for Lax-Friedrichs Scheme at t = ' num2str(t)])
    end
        
    %% store this round vn+1 for the next time step
    [un1, un2, un3, F1, F2, F3] = initial(h,u,v,g); % using the reset conserved variables calculate vn for next time step
end

end


%% ======================= End of the Main Function =======================


%% ======================= Start of Supporting functions ==================
function depth = H_initial(x) % Defines initial depth
depth = 2.0; % initial depth of the water on the upstream of the dam
dam_wall = 0; % dam wall to seperate the up & down side of the stream

if x >= dam_wall 
    depth = 1.0; % define depth of the downstream after the damwall  
end

end

function [h,u,v] = boundary(h1,u1,v1,m) % Function to impose ghost cells in each side
h = [h1(1) h1 h1(m)];
u = [u1(1) u1 u1(m)];
v = [v1(1) v1 v1(m)];
end

function [un1, un2, un3, F1, F2, F3] = initial(h,u,v,g) % Defines initial conserved variables and flux function
un1 = h; % set conserved variables
un2 = h.*u;
un3 = h.*v;

F1 = h.*u; % set flux variables correspondingly
F2 = h.*u.^2 + (g.*h.^2) / 2;
F3 = h.*u.*v;
end

function dt  = time_step(dx,c,u,g,h) % Function to calculate time steps 
Lamda_max = max(abs(u) + sqrt(g * h)); % Calculates max wave speed
dt = c * min(dx / Lamda_max); % Calculates timestep
end

function [Lamda_max_bar1, Lamda_max_bar2] = lamda_max(hu_i,h_i,hu_i_p_1,h_i_p_1,hu_i_m_1,h_i_m_1,g) %Function for lamda_max i bar and lamda_max i+1 bar
Lamda_max_bar1 = max(abs(hu_i ./ h_i + sqrt(g * h_i)), abs(hu_i_p_1 ./ h_i_p_1 + sqrt(g * h_i_p_1))); %for i+1/2
Lamda_max_bar2 = max(abs(hu_i_m_1 ./ h_i_m_1 + sqrt(g * h_i_m_1)), abs(hu_i ./ h_i + sqrt(g * h_i)));% for i-1/2
end

function[h,u,v] = Re_initial(U1,U2,U3,m) % Function that re-Define conserved variables and flux function for each iteration
h = U1(2:m+1); % Calculates new h, u, v values for Lax-F
u = U2(2:m+1)./U1(2:m+1); % Reset without the ghost cell imposed
v = U3(2:m+1)./U1(2:m+1); % Reset without the ghost cell imposed

[h,u,v] = boundary(h,u,v,m);  % Consider ghost cells again
end
% ======================= The End of Program ==============================
