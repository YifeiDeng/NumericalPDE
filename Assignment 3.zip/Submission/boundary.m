% Function to impose ghost cells in each side
function [h,u,v] = boundary(h1,u1,v1,m)
h = [h1(1) h1 h1(m)];
u = [u1(1) u1 u1(m)];
v = [v1(1) v1 v1(m)];
end

