% Function to calculate time steps in 2D
function dt  = time_step_2D(dx,dy,c,u,v,g,h) 
Lamda_max_x = max(abs(u) + sqrt(g * h)); % Calculates max wave speed for x
Lamda_max_y = max(abs(v) + sqrt(g * h)); % Calculates max wave speed for y
dt = 0.5 * c * min(min(dx ./ Lamda_max_x), min(dy ./ Lamda_max_y)); % Calculates timestep
end