 % Defines initial conserved variables and flux function in 2D
function [un1, un2, un3, F1, F2, F3, G1, G2, G3] = initial_2D(h,u,v,g)
un1 = h; % set conserved variables
un2 = h.*u;
un3 = h.*v;

F1 = h.*u; % set flux variables correspondingly for flux F in x-direction
F2 = h.*u.^2 + (g.*h.^2) / 2;
F3 = h.*u.*v;

G1 = h.*v; % set flux variables correspondingly for flux G in y-direction
G2 = h.*u.*v;
G3 = h.*v.^2 + (g.*h.^2) / 2;
end