% Function that re-Define conserved variables and flux function for each iteration in 2D
function[h,u,v] = Re_initial_2D(U1,U2,U3,m) 
h = U1(2:m+1,2:m+1); % Calculates new h, u, v values for Lax-F
u = U2(2:m+1,2:m+1)./U1(2:m+1,2:m+1); % Reset without the ghost cell imposed
v = U3(2:m+1,2:m+1)./U1(2:m+1,2:m+1); % Reset without the ghost cell imposed

[h,u,v] = boundary_2D(h,u,v,m);  % Consider ghost cells again
end