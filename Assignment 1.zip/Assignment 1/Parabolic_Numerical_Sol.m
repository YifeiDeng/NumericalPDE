function [execute_time_1,execute_time_2,dt1,dt2,dt_adv,dt_diff]=Parabolic_Numerical_Sol(N,a,eta,cfl,t_end,n_methods)
    % Winter 2020
    % Assignment 1 Question $7 b
    
    % Name: Yifei Deng
    
    % spatial step
    h=(20./N);
 
    %Two relevant time step dt_adv and dt_diff
    dt_adv=h/a;
    dt_diff=0.5*h^2/eta;
 
    % CFl timestep limit for the explicit methods dt1
    % And CFl timestep limit for the semi-implicit methods dt2
    dt1=0.5*cfl*min(dt_adv,dt_diff);
    dt2=cfl*dt_adv;
 
    % number of timesteps to be taken for method 1, n_it1
    % number of timesteps to be taken for method 2, n_it2
    n_it1=t_end/dt1;
    n_it2=t_end/dt2;
 
    % initialize some arrays
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % spatial grid 
    x=(-10:h:10-h);
    % arrays for the numerical approximations at times n and n+1
    v_new=zeros(N,n_methods);
    v_old=zeros(N,n_methods);
    
    % the initial condition
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:n_methods
       v_old(:,i)=1/sqrt(0.01)*exp((-x.^2)./(4.*eta*0.01));
    end
    % get the matrices for the semi-implicit method
    % A V(n+1) = B V(n)
    [A,B]=mat_parabolic_semi(N,a,eta,h,dt2);
    
    % the main iteration loop
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tic
    for iter = 1:n_it1
        % method 1: the explicit method
        const1=a*dt1/h;
        const2=eta*dt1/h^2;
        
        v_new(2:N-1,1)=v_old(2:N-1,1)-const1*(v_old(2:N-1,1)-v_old(1:N-2,1))...
                   +const2*(v_old(3:N,1)-2*v_old(2:N-1,1)+v_old(1:N-2,1));
        v_new(N,1)=v_old(N,1)-const1*(v_old(N,1)-v_old(N-1,1))...
               +const2*(v_old(1,1)-2*v_old(N,1)+v_old(N-1,1));
        v_new(1,1)=v_old(1,1)-const1*(v_old(1,1)-v_old(N,1))...
               +const2*(v_old(2,1)-2*v_old(1,1)+v_old(N,1));
       
        % prepare for the next iteration
        v_old(:,1)=v_new(:,1);
    end
    execute_time_1=toc;
    tic
    for iter = 1:n_it2
        % method 2: the semi-implicit method (the periodicity
        %    is taken into account in the matrices A and B)
        v_new(:,2)=A\(B*v_old(:,2));
 
        % prepare for the next iteration
        v_old(:,2)=v_new(:,2);
    end
    execute_time_2=toc;
end

