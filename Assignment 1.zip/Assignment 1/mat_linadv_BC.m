% the matrices for the implicit method
%-------------------------
% implicit central in space (BC)
function [A,B]=mat_linadv_BC(N,a,h,dt)
  e = ones(N,1);
  A = spdiags([-0.5*a*dt/h*e e 0.5*a*dt/h*e], [-1 0 1], N, N);
  A(1,N)=-0.5*a*dt/h;
  A(N,1)=0.5*a*dt/h;
  B=speye(N);
end