% Question 6 function with boundary condition u2(x,0)=exp(-50*(x-.5).^2)
% to calculate the results for the four different methods with u2 BC
function v_new=linadv_Numercial_Sol_IC1(a,N,cfl,t_end,n_methods)
    h =(1./(N));
    dt=cfl*h/a;
    x=(0:h:1-h);
    n_it=t_end/dt;
    t=(0:dt:n_it*dt);
 
    v_new=zeros(N,n_methods);
    v_old=zeros(N,n_methods);
 
    for i=1:n_methods
       v_old(:,i)=exp(-50*(x-.5).^2);
    end

    % get the matrices for the implicit method
    % A V(n+1) = B V(n)
    [A,B]=mat_linadv_BC(N,a,h,dt);
    
    % get the matrices for the Crank-Nicolson method
    % A1 V(n+1) = B1 V(n)
    [A1,B1]=mat_linadv_CN(N,a,h,dt);

    % the main iteration loop
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for iter = 1:n_it

        % method 1: FU (treat the first point separately
        %    taking into account the periodicity)
        v_new(2:N,1)=v_old(2:N,1)-a*dt/h*(v_old(2:N,1)-v_old(1:N-1,1));
        v_new(1,1)=v_old(1,1)-a*dt/h*(v_old(1,1)-v_old(N,1));
        % method 2: the implicit method (the periodicity
        %    is taken into account in the matrices A and B)
        v_new(:,2)=A\(B*v_old(:,2));
        
        % method 3: Crank-Nicolson Method using the implicit method
        % the periodicity is taken into account in the matrices A and B
        v_new(:,3)=A1\(B1*v_old(:,3));
        
        % method 4: Lax-Wendroff method
        cons1=0.5*a*dt/h;
        cons2=0.5*a^2*dt^2/h^2;
        
        v_new(2:N-1,4)=v_old(2:N-1,4)-cons1*(v_old(3:N,4)-v_old(1:N-2,4))...
                       +cons2*(v_old(3:N,4)-2*v_old(2:N-1,4)+v_old(1:N-2,4));
        v_new(N,4)=v_old(N,4)-cons1*(v_old(1,4)-v_old(N-1,4))...
                       +cons2*(v_old(1,4)-2*v_old(N,4)+v_old(N-1,4));
        v_new(1,4)=v_old(1,4)-cons1*(v_old(2,4)-v_old(N,4))...
                       +cons2*(v_old(2,4)-2*v_old(1,4)+v_old(N,4));
		v_old=v_new;
    end
end

