% the matrices for the implicit method
%-------------------------
% implicit central in space (CN)
function [A1,B1]=mat_linadv_CN(N,a,h,dt)
  e = ones(N,1);
  A1 = spdiags([-0.25*a*dt/h*e e 0.25*a*dt/h*e], [-1 0 1], N, N);
  A1(1,N)=-0.25*a*dt/h;
  A1(N,1)=0.25*a*dt/h;
  B1 = spdiags([0.25*a*dt/h*e e -0.25*a*dt/h*e], [-1 0 1], N, N);
  B1(1,N)=0.25*a*dt/h;
  B1(N,1)=-0.25*a*dt/h;
end
