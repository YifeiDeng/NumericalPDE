function linadv

    % Winter 2020
    % Assignment 1 question#6
    
    % Name: Yifei Deng

    % first initialize some parameters  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % the advection speed
    a=1.;
    % number of grid points in space (not counting the point at x=1, which is the same as the point at x=0, due to the periodicity)
    N=50;
    % spatial step
    h =(1./(N));
    % safety constant for stability (should be smaller than 1)
    cfl=.8;
    % CFl timestep limit for the explicit methods
    dt=cfl*h/a;
    % time at which we want to end the simulation
    t_end=1.;
    % number of timesteps to be taken
    n_it=t_end/dt;
    % number of different methods we want to try
    n_methods=4;

    % initialize some arrays
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % spatial grid (not including the point at x=1, which is the same as the point at x=0, due to the periodicity)
    x=(0:h:1-h);
    % temporal grid
    t=(0:dt:n_it*dt);
    % arrays for the numerical approximations at times n and n+1
    v_new1=zeros(N,n_methods);
    v_old1=zeros(N,n_methods);
    
    v_new2=zeros(N,n_methods);
    v_old2=zeros(N,n_methods);
    
    % array for the exact solution
    v_exact1=zeros(N,1);
    v_exact2=zeros(N,1);

    % the initial condition
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:n_methods
       v_old1(:,i)=exp(-50*(x-.5).^2.);
       v_old2(:,i)=(1.+sign(x-0.5))/2.;
    end

    % get the matrices for the implicit method
    % A V(n+1) = B V(n)
    [A,B]=mat_linadv_BC(N,a,h,dt);
    
    % get the matrices for the Crank-Nicolson method
    % A1 V(n+1) = B1 V(n)
    [A1,B1]=mat_linadv_CN(N,a,h,dt);

    % the main iteration loop
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for iter = 1:n_it
        %Problem 1
        
        % method 1: FU (treat the first point separately
        %    taking into account the periodicity)
        v_new1(2:N,1)=v_old1(2:N,1)-a*dt/h*(v_old1(2:N,1)-v_old1(1:N-1,1));
        v_new1(1,1)=v_old1(1,1)-a*dt/h*(v_old1(1,1)-v_old1(N,1));
        % method 2: the BC implicit method (the periodicity
        %    is taken into account in the matrices A and B)
        v_new1(:,2)=A\(B*v_old1(:,2));
        % method 3: Crank-Nicolson Method using the implicit method
        % the periodicity is taken into account in the matrices A and B
        v_new1(:,3)=A1\(B1*v_old1(:,3));
        % method 4: Lax-Wendroff method
        cons1=0.5*a*dt/h;
        cons2=0.5*a^2*dt^2/h^2;
        
        v_new1(2:N-1,4)=v_old1(2:N-1,4)-cons1*(v_old1(3:N,4)-v_old1(1:N-2,4))...
                       +cons2*(v_old1(3:N,4)-2*v_old1(2:N-1,4)+v_old1(1:N-2,4));
        v_new1(N,4)=v_old1(N,4)-cons1*(v_old1(1,4)-v_old1(N-1,4))...
                       +cons2*(v_old1(1,4)-2*v_old1(N,4)+v_old1(N-1,4));
        v_new1(1,4)=v_old1(1,4)-cons1*(v_old1(2,4)-v_old1(N,4))...
                       +cons2*(v_old1(2,4)-2*v_old1(1,4)+v_old1(N,4));
        % the exact solution with a=1
        v_exact1(:) = exp(-50*(x-a*t(iter+1)-.5).^2) + ...
                     exp(-50*(x-a*t(iter+1)+.5).^2);
                 
        % graphical output
        
        %Problem 1 with u1(x,0)=exp(-50*(x-.5).^2)
        figure(1)
        plot(x,v_exact1(:),'^r-')
        hold on
        for i=1:n_methods
           plot(x,v_new1(:,1),'*b-')
           plot(x,v_new1(:,2),'+g-')
           plot(x,v_new1(:,3),'sm-')
           plot(x,v_new1(:,4),'xk-')
        end
        axis([0 1 -.2 1.2])
        xlabel('x')
        ylabel('v')
        title('linear advection simulation Problem 1')
        legend('Exact','FU','BC','CN','LW')
        hold off
        pause(0.001)
        % prepare for the next iteration
        v_old1=v_new1;
    end 
    
    for iter = 1:n_it
        % Problem 2:
        
        % method 1: FU (treat the first point separately
        %    taking into account the periodicity)
        v_new2(2:N,1)=v_old2(2:N,1)-a*dt/h*(v_old2(2:N,1)-v_old2(1:N-1,1));
        v_new2(1,1)=v_old2(1,1)-a*dt/h*(v_old2(1,1)-v_old2(N,1));
        % method 2: the BC implicit method (the periodicity
        %    is taken into account in the matrices A and B)
        v_new2(:,2)=A\(B*v_old2(:,2));
        % method 3: Crank-Nicolson Method using the implicit method
        % the periodicity is taken into account in the matrices A and B
        v_new2(:,3)=A1\(B1*v_old2(:,3));
        % method 4: Lax-Wendroff method
        cons1=0.5*a*dt/h;
        cons2=0.5*a^2*dt^2/h^2;
        
        v_new2(2:N-1,4)=v_old2(2:N-1,4)-cons1*(v_old2(3:N,4)-v_old2(1:N-2,4))...
                       +cons2*(v_old2(3:N,4)-2*v_old2(2:N-1,4)+v_old2(1:N-2,4));
        v_new2(N,4)=v_old2(N,4)-cons1*(v_old2(1,4)-v_old2(N-1,4))...
                       +cons2*(v_old2(1,4)-2*v_old2(N,4)+v_old2(N-1,4));
        v_new2(1,4)=v_old2(1,4)-cons1*(v_old2(2,4)-v_old2(N,4))...
                       +cons2*(v_old2(2,4)-2*v_old2(1,4)+v_old2(N,4));
                           
        %the exact solution with a=1 (until t=1, we need 3 unit
        %jumps in the solution...)
        v_exact2(:) = (1.+sign((x-a*t(iter+1))+0.5))/2. - ...
                    (1.+sign((x-a*t(iter+1))-0.0))/2. + ...
                    (1.+sign((x-a*t(iter+1))-0.5))/2.;
 
        
        %Problem 2 with u2(x,0)=(1.+sign(x-0.5))/2.
        figure(2)
        plot(x,v_exact2(:),'^r-')
        hold on
        for i=1:n_methods
           plot(x,v_new2(:,1),'*b-')
           plot(x,v_new2(:,2),'+g-')
           plot(x,v_new2(:,3),'sm-')
           plot(x,v_new2(:,4),'xk-')
        end
        axis([0 1 -.6 1.6])
        xlabel('x')
        ylabel('v')
        title('linear advection simulation Problem 2')
        legend('Exact','FU','BC','CN','LW')
        hold off
        pause(0.001)
        % prepare for the next iteration
        v_old2=v_new2;
    end
end


% the matrices for the implicit method
%-------------------------
% implicit central in space (BC)
function [A,B]=mat_linadv_BC(N,a,h,dt)
  e = ones(N,1);
  A = spdiags([-0.5*a*dt/h*e e 0.5*a*dt/h*e], [-1 0 1], N, N);
  A(1,N)=-0.5*a*dt/h;
  A(N,1)=0.5*a*dt/h;
  B=speye(N);
end

% the matrices for the implicit method
%-------------------------
% implicit central in space (CN)
function [A1,B1]=mat_linadv_CN(N,a,h,dt)
  e = ones(N,1);
  A1 = spdiags([-0.25*a*dt/h*e e 0.25*a*dt/h*e], [-1 0 1], N, N);
  A1(1,N)=-0.25*a*dt/h;
  A1(N,1)=0.25*a*dt/h;
  B1 = spdiags([0.25*a*dt/h*e e -0.25*a*dt/h*e], [-1 0 1], N, N);
  B1(1,N)=0.25*a*dt/h;
  B1(N,1)=-0.25*a*dt/h;
end