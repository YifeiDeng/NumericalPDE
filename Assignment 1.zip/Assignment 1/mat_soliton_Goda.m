% the matrices for the implicit method
%-------------------------
% implicit scheme due to Goda
function [A,B]=mat_soliton_Goda(N,h,dt,v_n2,v_old)
        e = ones(N,1);
  
        % set coefficient for vi-1=a, vi+1=c, vi+2 & vi-2 respectfully
        % in this case, we have parrell vector form for 1:N-1 and 2:N
        % and we use this for the coefficient case
        
        % c coefficient for vi-1_n+1
        for i = 2:N
            v_n2(i-1,1)=dt/h*(v_old(i,2)+v_old(i-1,2))+dt/h^3;
        end
        % a coefficient for vi+1_n+1
        for i = 1:N-1
            v_n2(i+1,2)=-dt/h*(v_old(i,2)+v_old(i+1,2))-dt/h^3;
        end 
        
        b=0.5*dt/h^3;
        d=-0.5*dt/(h^3);
  
        % Build up the A matrix and add the deleted elements at each corner
        % of the matrix like what we did in linear advection model for CN
        A = spdiags([d*e v_n2(:,1) e v_n2(:,2) b*e],-2:2, N, N);
        A(1,N-1)= d;
        A(2,N)=d;
        A(1,N)=dt*(v_old(1,2)+v_old(N,2))/h+dt/h^3;
        A(N,2)=b;
        A(N-1,1)=b;
        A(N,1)=-dt*(v_old(N,2)+v_old(N-1,2))/h-dt/h^3;
  
        % set B matrix to be the identity matrix
        B = speye(N);
end


