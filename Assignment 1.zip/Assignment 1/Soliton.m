function Soliton
    % Winter 2020
    % Assignment 1 question#6
    
    % Name: Yifei Deng
    
    % first initialize some parameters  
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    % initialized v=16 & x_0=0
    v=16;
    x_0=0;
    % spatial steps
    h=0.1;
    % spatial grid
    N=16/h;
    % Calculate time step sizes for both method
    % i.e. for u_max, since we have the initial
    % condition where u(x,0)= -8/(cosh(2x))^2
    % and u1(x,t)=-8/(cosh(2x-32*t))^2
    % so the u_max would be when x=16t for u(x,t).
    % i.e., u_max=8/(cosh(0))^2=-8
    % set cfl = 0.8 in this case
    u_max=-8.;
    dt=h/(4/h^2+abs(6*u_max))*0.8;
    % time at which we want to end the simulation
    t_end=2.;
%   t_end=1.;
    % number of timesteps to be taken
    n_it=t_end/dt;
    % number of method we would like to try
    n_methods=2;
    % initialize some arrays
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % spatial grid (not including the point at x=8, which is the same as the point at x=-8, due to the periodic condition)
    x=(-8:h:8-h);
    % temporal grid
    t=(0:dt:n_it*dt);
    % arrays for the numerical approximations at times n and n+1
    v_new=zeros(N,n_methods);
    v_old=zeros(N,n_methods);
    % in this case we use v_n to be the vn+1 for the first step and 
    % vn in the future possible step and v_old(:,1) will be vn for the first
    % step and vn-1 for all future step
    v_n=zeros(N,n_methods);
    % set v_n2 for method# 2
    v_n2=zeros(N,n_methods);
    % array for the exact solution
    v_exact=zeros(N,1);

    % the initial condition
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    for i=1:n_methods
%        8.c two-soliton for 

%       v_old(:,i)=-8./(cosh(2*x+8).^2)-2./(cosh(x).^2);

%        8.d gaussian profile for

%        v_old(:,i)=-5*exp(-(x/2).^2);

%        8.b for
       v_old(:,i) = -8./cosh(2*x).^ 2;
    end
    
    %% for method #1 leap-frog
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    

    % first timestep (v_n is vn+1 for this step, will be vn for future steps)
    for i = 3:N-2
        v_n(i,1)=v_old(i,1)+dt*(v_old(i-1,1)+v_old(i,1)+v_old(i+1,1))*(v_old(i+1,1)+v_old(i-1,1))/h...
                 -0.5*dt*(v_old(i+2,1)-2*v_old(i+1,1)+2*v_old(i-1,1)-v_old(i-2,1))/h^3;
    end
    
    v_n(1,1)=v_old(1,1)+dt*(v_old(N,1)+v_old(1,1)+v_old(2,1))*(v_old(2,1)-v_old(N,1))/h...
                  -0.5*dt*(v_old(3,1)-2*v_old(2,1)+2*v_old(N,1)-v_old(N-1,1))/h^3;            
    v_n(2,1)=v_old(2,1)+dt*(v_old(1,1)+v_old(2,1)+v_old(3,1))*(v_old(3,1)-v_old(1,1))/h...
                  -0.5*dt*(v_old(4,1)-2*v_old(3,1)+2*v_old(1,1)-v_old(N,1))/h^3;
    v_n(N-1,1)=v_old(N-1,1)+dt*(v_old(N-2,1)+v_old(N-1,1)+v_old(N,1))*(v_old(N,1)-v_old(N-2,1))/h...
                  -0.5*dt*(v_old(1,1)-2*v_old(N,1)+2*v_old(N-2,1)-v_old(N-3,1))/h^3;
    v_n(N,1)=v_old(N,1)+dt*(v_old(N-1,1)+v_old(N,1)+v_old(1,1))*(v_old(1,1)-v_old(N-1,1))/h...
                  -0.5*dt*(v_old(2,1)-2*v_old(1,1)+2*v_old(N-1,1)-v_old(N-2,1))/h^3;

    % The main loop
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
    for iter = 2:n_it
        % method 1: the leapfrog explicit scheme
        
        % in the future step, v_n =vn and v_new = vn+1 and v_old=vn-1 
        for i=3:N-2
            v_new(i,1)=v_old(i,1)+2*dt*((v_n(i-1,1)+v_n(i,1)+v_n(i+1,1))*(v_n(i+1,1)-v_n(i-1,1))/(h)...
                       -(v_n(i+2,1)-2*v_n(i+1,1)+2*v_n(i-1,1)-v_n(i-2,1))/(2*h^3));
        end
        
        v_new(1,1)=v_old(1,1)+2*dt*((v_n(N,1)+v_n(1,1)+v_n(2,1))*(v_n(2,1)-v_n(N,1))/(h)...
                   -(v_n(3,1)-2*v_n(2,1)+2*v_n(N,1)-v_n(N-1,1))/(2*h^3));
        v_new(2,1)=v_old(2,1)+2*dt*((v_n(1,1)+v_n(2,1)+v_n(3,1))*(v_n(3,1)-v_n(1,1))/(h)+...
                   - (v_n(4,1)-2*v_n(3,1)+2*v_n(1,1)-v_n(N,1))/(2*h^3));
        v_new(N-1,1)=v_old(N-1,1)+2*dt*((v_n(N-2,1)+v_n(N-1,1)+v_n(N,1))*(v_n(N,1)+...
                   -v_n(N-2,1))/(h)-(v_n(1,1)-2*v_n(N,1)+2*v_n(N-2,1)-v_n(N-3,1))/(2*h^3));
        v_new(N,1)=v_old(N,1)+2*dt*((v_n(N-1,1)+v_n(N,1)+v_n(1,1))*(v_n(1,1)-v_n(N-1,1))/(h)+...
                   -(v_n(2,1)-2*v_n(1,1)+2*v_n(N-1,1)-v_n(N-2,1))/(2*h^3));
               
        % in this case, for periodicity, we add some extra waves for each
        % time shift, like the linear advection one we done for Q6
               
        % the exact solution for part b
        v_exact(:) = -0.5*v./(cosh(0.5*sqrt(v)*(x-v*t(iter)-x_0))).^2....
                     -0.5*v./(cosh(0.5*sqrt(v)*(x-v*(t(iter)-1)-x_0))).^2....
                     -0.5*v./(cosh(0.5*sqrt(v)*(x-v*(t(iter)-2)-x_0))).^2;       
        
        % prepared for the next iteration
        v_old(:,1)=v_n(:,1);
        v_n(:,1)=v_new(:,1);
    %% for method#2 Implicite Goda
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % get the matrices for the implicit Goda method
        % in this case we updated the matrix for each timesteps
        % A1 V(n+1) = B1 V(n)
        [A,B]=mat_soliton_Goda(N,h,dt,v_n2,v_old);
        % Solve the vn+1 and store it as v_new
        v_new(:,2)=A\(B*v_old(:,2));

        % prepared for the next iteration
        v_old(:,2)=v_new(:,2);
        
        %graph the solution in moving phase curves for 8.b. IC
%         plot(x,v_exact(:),'^r-')
%         hold on
%         plot(x,v_new(:,1),'og-')
%         plot(x,v_new(:,2),'*b-')
%         axis ([-8,8,-9,1])
%         xlabel('x')
%         ylabel('v')
%         legend('exact','leapfrog','implicit method Goda')
%         hold off
%         pause(0.0001)

    end
        % plot the solution
        plot(x,v_exact(:),'^r-')
        hold on
        plot(x,v_new(:,1),'og-')
        plot(x,v_new(:,2),'*b-')
        hold off
        axis ([-8,8,-9,1])
        xlabel('x')
        ylabel('v')
        title('Soliton for t=2')
        legend('exact','leapfrog','implicit method Goda')
     
end

% the matrices for the implicit method
%-------------------------
% implicit scheme due to Goda
function [A,B]=mat_soliton_Goda(N,h,dt,v_n2,v_old)
        e = ones(N,1);
  
        % set coefficient for vi-1=a, vi+1=c, vi+2 & vi-2 respectfully
        % in this case, we have parrell vector form for 1:N-1 and 2:N
        % and we use this for the coefficient case
        
        % c coefficient for vi-1_n+1
        for i = 2:N
            v_n2(i-1,1)=dt/h*(v_old(i,2)+v_old(i-1,2))+dt/h^3;
        end
        % a coefficient for vi+1_n+1
        for i = 1:N-1
            v_n2(i+1,2)=-dt/h*(v_old(i,2)+v_old(i+1,2))-dt/h^3;
        end 
        
        b=0.5*dt/h^3;
        d=-0.5*dt/(h^3);
  
        % Build up the A matrix and add the deleted elements at each corner
        % of the matrix like what we did in linear advection model for CN
        A = spdiags([d*e v_n2(:,1) e v_n2(:,2) b*e],-2:2, N, N);
        A(1,N-1)= d;
        A(2,N)=d;
        A(1,N)=dt*(v_old(1,2)+v_old(N,2))/h+dt/h^3;
        A(N,2)=b;
        A(N-1,1)=b;
        A(N,1)=-dt*(v_old(N,2)+v_old(N-1,2))/h-dt/h^3;
  
        % set B matrix to be the identity matrix
        B = speye(N);
end
