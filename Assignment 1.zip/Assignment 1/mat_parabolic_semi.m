% the matrices for the semi-implicit method
%-------------------------
% semi-implicit
function [A,B]=mat_parabolic_semi(N,a,eta,h,dt1)
  e = ones(N,1);
  B = spdiags([1-a*dt1/h*e a*dt1/h*e], [0 1], N, N);
  B(1,N)=a*dt1/h;
  B(N,1)=-a*dt1/h;
  A = spdiags([-eta*dt1/h^2*e (1+2*eta*dt1/h^2)*e -eta*dt1/h^2*e], [-1 0 1], N, N);
  A(1,N)=-eta*dt1/h^2;
  A(N,1)=-eta*dt1/h^2;
end


