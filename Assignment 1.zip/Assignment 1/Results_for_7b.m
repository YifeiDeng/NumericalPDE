%Given number of grid points in space
n_points=[10,20,40,80,160,320,640,1200,2560];

%Initial some values
a=1;
eta=2;
cfl=0.9;
t_end=1-0.01;
n_methods=2;
L=length(n_points);

%Create cell for storing the results
results=zeros(L,6);

%Storing the results for each values of n
for iter=1:L
[execute_time_1,execute_time_2,dt1,dt2,dt_adv,dt_diff]=Parabolic_Numerical_Sol(n_points(iter),a,eta,cfl,t_end,n_methods);
results(iter,:)=[execute_time_1;execute_time_2;dt1;dt2;dt_adv;dt_diff];
end

%Create a table to compare the results for each n points
T=table(results(:,1),results(:,2),results(:,3),results(:,4),results(:,5),results(:,6));
T.Properties.VariableNames={'Execution Time for Method1','Execution Time for Method2','Timesteps Size for Method #1','Timesteps Size for Method #2','Advection Time Step Size','Dissipation Time Step Size'};
T.Properties.RowNames={'n=11';'n=21';'n=41';'n=81';'n=161';'n=321';'n=641';'n=1281';'n=2561';};