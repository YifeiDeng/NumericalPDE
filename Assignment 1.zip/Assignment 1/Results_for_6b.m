a=1.;
N1=50;
N2=100;
t_end=1.;
cfl=.8;
n_methods=4;

Final_N1_B1=zeros(N1,n_methods);
Final_N2_B1=zeros(N2,n_methods);
Final_N1_B2=zeros(N1,n_methods);
Final_N2_B2=zeros(N2,n_methods);

Final_N1_B1=linadv_Numercial_Sol_IC1(a,N1,cfl,t_end,n_methods);
Final_N2_B1=linadv_Numercial_Sol_IC1(a,N2,cfl,t_end,n_methods);
Final_N1_B2=linadv_Numercial_Sol_IC2(a,N1,cfl,t_end,n_methods);
Final_N2_B2=linadv_Numercial_Sol_IC2(a,N2,cfl,t_end,n_methods);





